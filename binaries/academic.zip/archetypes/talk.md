+++
title = ""
abstract = ""
abstract_short = ""
event = ""
event_url = ""
location = ""

selected = false
math = false
highlight = true

url_pdf = ""
url_slides = ""
url_video = ""

# Optional featured image (relative to `static/img/` folder).
[header]
image = ""
caption = ""

+++
